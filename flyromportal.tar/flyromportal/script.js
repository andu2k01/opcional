/*
Els panells amb imatges són una mica bruscos quan tots els panells estan en transició.!
*/
var btn = $('button');
var body = $("body");

btn.on("click", function() {
  body.toggleClass("hide-images");
});
